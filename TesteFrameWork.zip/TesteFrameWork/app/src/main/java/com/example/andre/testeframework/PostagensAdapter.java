package com.example.andre.testeframework;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class PostagensAdapter extends ArrayAdapter<Postagens> {

    private final Context context;
    private final ArrayList<Postagens> elementos;

    public PostagensAdapter(Context context, ArrayList<Postagens>  elementos)  {
        super(context,  R.layout.linha_posts,  elementos);
        this.context=  context;
        this.elementos=  elementos;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater=  (LayoutInflater)  context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView=  inflater.inflate(R.layout.linha_posts,  parent,  false);
        TextView user=  (TextView)  rowView.findViewById(R.id.t1);
        TextView titulo=  (TextView)  rowView.findViewById(R.id.t2);
        TextView corpo=  (TextView)  rowView.findViewById(R.id.t3);
        user.setText(elementos.get(position).getUserId());
        titulo.setText(elementos.get(position).getTitle());
        corpo.setText(elementos.get(position).getBody());
        return rowView;
    }
}
