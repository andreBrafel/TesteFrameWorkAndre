package com.example.andre.testeframework;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListaPostagens extends AppCompatActivity {

    Principal main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lista_posts);

        main = new Principal();

        ListView lista = (ListView) findViewById(R.id.lista);
        ArrayList<Postagens> postagens = main.postagens;
        ArrayAdapter adapter = new PostagensAdapter(this, postagens);
        lista.setAdapter(adapter);
    }

}
