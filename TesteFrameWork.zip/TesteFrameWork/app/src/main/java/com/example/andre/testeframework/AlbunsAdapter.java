package com.example.andre.testeframework;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class AlbunsAdapter extends ArrayAdapter<Albuns>  {
    private final Context context;
    private final ArrayList<Albuns> elementos;

    public AlbunsAdapter(Context context,ArrayList<Albuns>  elementos){
        super(context, R.layout.linha_albuns,elementos);
        this.context=context;
        this.elementos=elementos;
    }

    @Override
    public View getView(int position,View convertView,ViewGroup parent){
        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView=inflater.inflate(R.layout.linha_albuns,parent,false);
        TextView userId=(TextView)rowView.findViewById(R.id.userId);
        TextView titulo=(TextView)rowView.findViewById(R.id.title);
        userId.setText(elementos.get(position).getUserId());
        titulo.setText(elementos.get(position).getTitle());
        return rowView;
    }
}
