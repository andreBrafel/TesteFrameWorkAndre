package com.example.andre.testeframework;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListaAlbuns extends AppCompatActivity {

    Principal main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lista_albuns);

        main = new Principal();

        ListView lista = (ListView) findViewById(R.id.lista);
        ArrayList<Albuns> albuns = main.albuns;
        ArrayAdapter adapter = new AlbunsAdapter(this, albuns);
        lista.setAdapter(adapter);

    }
}
