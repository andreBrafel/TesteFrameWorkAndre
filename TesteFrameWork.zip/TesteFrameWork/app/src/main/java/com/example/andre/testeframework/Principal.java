package com.example.andre.testeframework;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Looper;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Principal extends AppCompatActivity {

    //Arrays
    public static ArrayList<Postagens> postagens;
    public static Postagens post;
    public static ArrayList<Albuns> albuns;
    public static Albuns comm;
    public static ArrayList<Todos> todos;
    public static Todos tod;
    //Lista URL
    private ArrayList<String> url;
    //Lista do Banco Local
    String POSTS = "posts";
    String ALBUMS = "albums";
    String TODOS = "todos";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.principal);

        postagens = new ArrayList<Postagens>();
        albuns = new ArrayList<Albuns>();
        todos = new ArrayList<Todos>();

        url = new ArrayList<String>();
        url.add("https://jsonplaceholder.typicode.com/posts");
        url.add("https://jsonplaceholder.typicode.com/albums");
        url.add("https://jsonplaceholder.typicode.com/todos");

        Button posts = (Button) findViewById(R.id.btPostagens);
        Button albums = (Button) findViewById(R.id.btAlbuns);
        Button todos = (Button) findViewById(R.id.btTodos);

        if (verificaConexao()){
            new getDados().execute();
        } else{
            AlertDialog.Builder builder = new AlertDialog.Builder(Principal.this);
            builder.setTitle("Alerta!");
            builder.setMessage("Sem acesso a Internet\nO aplicativo não exibirá os dados!");
            builder.show();
            posts.setEnabled(false);
            albums.setEnabled(false);
            todos.setEnabled(false);
        }

        posts.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(Principal.this, ListaPostagens.class);
                startActivity(it);
            }
        });
        albums.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(Principal.this, ListaAlbuns.class);
                startActivity(it);
            }
        });
        todos.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(Principal.this, ListaTodos.class);
                startActivity(it);
            }
        });

    }

    /**
     * Classe de tarefa assíncrona para obter json fazendo chamada HTTP
     */
    private class getDados extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(Principal.this,"Download...",Toast.LENGTH_LONG).show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            Looper.prepare();
            HttpHandler sh = new HttpHandler();

            for (int k = 0; k < url.size(); k++) {

                // Fazendo uma solicitação para URL e obtendo resposta
                String jsonStr = sh.makeServiceCall(url.get(k));
                Log.d("Response: ", "> " + jsonStr);

                if (jsonStr != null) {

                    try {
                        String campo = url.get(k).replace("https://jsonplaceholder.typicode.com/", "");
                        //Salva Arquivo no Banco Local
                        if (campo.equals("posts")){
                            salvarArquivo(POSTS, jsonStr);
                        } else if (campo.equals("albums")){
                            salvarArquivo(ALBUMS, jsonStr);
                        } else if (campo.equals("todos")){
                            salvarArquivo(TODOS, jsonStr);
                        }
                        // Getting JSON Array node
                        JSONArray contacts = new JSONArray(jsonStr);

                        // looping em todos os contatos
                        for (int i = 0; i < contacts.length(); i++) {
                            JSONObject c = contacts.getJSONObject(i);
                            if (campo.equals("posts")){
                                post = new Postagens(c.getString("userId"), c.getString("id"), c.getString("title"), c.getString("body"));
                                postagens.add(post);
                            } else if(campo.equals("albums")){
                                comm = new Albuns(c.getString("userId"), c.getString("id"), c.getString("title"));
                                albuns.add(comm);
                            } else if(campo.equals("todos")){
                                tod = new Todos(c.getString("userId"), c.getString("id"), c.getString("title"), c.getBoolean("completed"));
                                todos.add(tod);
                            }

                        }

                    } catch (final JSONException e) {
                        Log.e("Response: ", "Json parsing error: " + e.getMessage());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(),
                                        "Json parsing error: " + e.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        });

                    }

                } else {
                    Log.e("Response: ", "Couldn't get json from server.");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Couldn't get json from server. Check LogCat for possible errors!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
            return null;
        }

    }
    /* Função para verificar existência de conexão com a internet
     */
    public boolean verificaConexao() {
        boolean conectado;
        ConnectivityManager conectivtyManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (conectivtyManager.getActiveNetworkInfo() != null
                && conectivtyManager.getActiveNetworkInfo().isAvailable()
                && conectivtyManager.getActiveNetworkInfo().isConnected()) {
            conectado = true;
        } else {
            conectado = false;
        }
        return conectado;
    }

    public void salvarArquivo(String nome, String arquivo){
        try {
            FileOutputStream fOut = openFileOutput(nome,MODE_WORLD_READABLE);
            fOut.write(arquivo.getBytes());
            fOut.close();
            Toast.makeText(getBaseContext(),"file saved",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public String lerArquivoLocalHost(String nome){
        try{
            FileInputStream fin = openFileInput(nome);
            Scanner scanner = new Scanner(fin);
            scanner.useDelimiter("\\Z");
            String temp = scanner.next();
            scanner.close();
            Toast.makeText(getBaseContext(),"file read",
                    Toast.LENGTH_SHORT).show();
            return temp;
        }catch(Exception e){

        }
        return "";
    }
    public void lerArquivoJson(String jsonStr, String campo){
        try {
            // Getting JSON Array node
            JSONArray contacts = new JSONArray(jsonStr);

            // looping em todos os contatos
            for (int i = 0; i < contacts.length(); i++) {
                JSONObject c = contacts.getJSONObject(i);
                if (campo.equals("posts")){
                    post = new Postagens(c.getString("userId"), c.getString("id"), c.getString("title"), c.getString("body"));
                    postagens.add(post);
                } else if(campo.equals("albums")){
                    comm = new Albuns(c.getString("userId"), c.getString("id"), c.getString("title"));
                    albuns.add(comm);
                } else if(campo.equals("todos")){
                    tod = new Todos(c.getString("userId"), c.getString("id"), c.getString("title"), c.getBoolean("completed"));
                    todos.add(tod);
                }
            }

        } catch (final JSONException e) {
            Log.e("Response: ", "Json parsing error: " + e.getMessage());
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(),
                            "Json parsing error: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });

        }
    }
}
